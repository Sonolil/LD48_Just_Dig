﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public static class AllStatic
{
    //public static Vector3Int WorldToTilePosition(this Tilemap map, Vector3 position) {
    //    var pos = position - map.transform.position;
    //    Vector3Int rpos = new Vector3Int((int)Mathf.Round(pos.x - 0.5f), (int)Mathf.Round(pos.y - 0.5f), 0);
    //    return rpos;
    //}
    //public static Vector3 TileToWorldPos(this Tilemap map, Vector3 position) {
    //    var pos = position - map.transform.position;
    //    Vector3Int rpos = new Vector3Int((int)Mathf.Round(pos.x - 0.5f), (int)Mathf.Round(pos.y - 0.5f), 0);
    //    return rpos;
    //}

}
