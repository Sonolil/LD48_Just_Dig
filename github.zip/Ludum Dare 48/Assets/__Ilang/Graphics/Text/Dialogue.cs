﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Ilang
{
    public class Dialogue : MonoBehaviour
    {

        void Awake() {
            GetComponent<TextMesh>();
        }

        // Update is called once per frame
        void Update() {

        }
    }
}