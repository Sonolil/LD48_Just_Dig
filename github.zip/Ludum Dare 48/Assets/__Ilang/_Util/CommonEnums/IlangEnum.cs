﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Ilang
{
    public enum eAutomation
    {
        Manual,
        OnAwake,
        OnEnable,
        OnDisable
    }
}